Paperly PDF — 51 private, in-browser PDF tools
================================================

This archive contains:
  paperly/            full source tree (React 19 + Vite 7 + TypeScript)
  paperly/dist/       production build, ready to deploy to any static host
                      (build command: npm run build, publish directory: dist)

Quick start
-----------
  npm install
  npm run dev        # local development
  npm run build      # production build (includes SEO prerender + offline SW)
  npm test           # 221 unit tests
  npx playwright test  # 73 end-to-end tests (install Chromium first)

Deploy
------
Netlify: connect the repo, build command `npm run build`, publish `dist`,
set PAPERLY_ORIGIN to your domain. Or drag the dist/ folder into any static host.

Everything runs client-side. No document is ever uploaded.

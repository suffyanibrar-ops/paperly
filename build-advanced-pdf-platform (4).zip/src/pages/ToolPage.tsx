import { ArrowRight, Info, ShieldCheck } from "lucide-react";
import { getTool, type Tool } from "@/lib/toolRegistry";
import { ToolShell, ToolTile } from "@/components/ui";
import { NotFoundPage } from "@/pages/Info";
import { MergeTool, SplitTool, OrganizeTool, RotateTool, CropTool } from "@/tools/Organize";
import { CompressTool, RepairTool, PageNumbersTool } from "@/tools/Optimize";
import { JpgToPdfTool, PdfToJpgTool } from "@/tools/ConvertImages";
import {
  PdfToWordTool,
  PdfToExcelTool,
  PdfToPptTool,
  WordToPdfTool,
  ExcelToPdfTool,
  PptToPdfTool,
  ExtractTextTool,
} from "@/tools/ConvertDocs";
import { EditPdfTool, SignPdfTool, WatermarkTool } from "@/tools/Edit";
import { ProtectTool, UnlockTool } from "@/tools/Security";
import { CompareTool, RedactTool } from "@/tools/RedactCompare";
import { OcrTool } from "@/tools/OcrTool";
import { MarkdownToPdfTool, PdfToMarkdownTool } from "@/tools/MarkdownTools";
import { BatesTool, FlattenTool, HeadersFootersTool, NUpTool, ResizeTool } from "@/tools/Advanced";
import { FillFormsTool, ScanTool } from "@/tools/FormsScan";
import { ArchiveTool, HtmlToPdfTool } from "@/tools/HtmlArchive";
import { BatchTool, CreateFormTool } from "@/tools/Pro";
import { ExtractImagesTool, ExtractPagesTool, RemovePagesTool, SummarizeTool } from "@/tools/ProExtras";

const TOOL_COMPONENTS: Record<string, () => React.ReactElement> = {
  merge: MergeTool,
  split: SplitTool,
  organize: OrganizeTool,
  rotate: RotateTool,
  crop: CropTool,
  compress: CompressTool,
  repair: RepairTool,
  "page-numbers": PageNumbersTool,
  "jpg-to-pdf": JpgToPdfTool,
  "pdf-to-jpg": PdfToJpgTool,
  "pdf-to-word": PdfToWordTool,
  "pdf-to-excel": PdfToExcelTool,
  "pdf-to-ppt": PdfToPptTool,
  "word-to-pdf": WordToPdfTool,
  "excel-to-pdf": ExcelToPdfTool,
  "ppt-to-pdf": PptToPdfTool,
  "extract-text": ExtractTextTool,
  edit: EditPdfTool,
  sign: SignPdfTool,
  watermark: WatermarkTool,
  protect: ProtectTool,
  unlock: UnlockTool,
  redact: RedactTool,
  compare: CompareTool,
  ocr: OcrTool,
  "markdown-to-pdf": MarkdownToPdfTool,
  "pdf-to-markdown": PdfToMarkdownTool,
  resize: ResizeTool,
  "n-up": NUpTool,
  "headers-footers": HeadersFootersTool,
  bates: BatesTool,
  "fill-forms": FillFormsTool,
  flatten: FlattenTool,
  scan: ScanTool,
  "html-to-pdf": HtmlToPdfTool,
  archive: ArchiveTool,
  batch: BatchTool,
  "create-form": CreateFormTool,
  "remove-pages": RemovePagesTool,
  "extract-pages": ExtractPagesTool,
  "extract-images": ExtractImagesTool,
  summarize: SummarizeTool,
};

const WIDE_TOOLS = new Set(["organize", "edit", "sign", "redact", "compare", "scan", "markdown-to-pdf", "pdf-to-markdown", "fill-forms", "html-to-pdf", "create-form", "extract-images"]);

function WideAside({ tool }: { tool: Tool }) {
  return (
    <div className="mt-6 grid gap-4 md:grid-cols-3">
      <div className="surface p-4">
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-ink/75">How it works</p>
        <ol className="mt-2.5 space-y-2.5">
          {tool.steps.map((step, i) => (
            <li key={i} className="flex gap-2.5">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-forest text-[10px] font-bold text-lime">{i + 1}</span>
              <p className="text-[12px] leading-relaxed text-ink/75">{step}</p>
            </li>
          ))}
        </ol>
      </div>
      <div className="rounded-2xl bg-forest p-4 text-paper">
        <ShieldCheck className="h-4 w-4 text-lime" />
        <p className="mt-2 text-[13px] font-semibold">Your file stays in this tab</p>
        <p className="mt-1 text-[11.5px] leading-relaxed text-paper/70">
          Rendering, editing and saving happen on your device. No upload request, no temporary server copy and no retention.
        </p>
        <a href="#/privacy" className="mt-2 inline-flex items-center gap-1 text-[11.5px] font-semibold text-lime hover:underline">
          Privacy promise <ArrowRight className="h-3 w-3" />
        </a>
      </div>
      <div className="surface p-4">
        {tool.note ? (
          <>
            <p className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-[0.1em] text-ink/75">
              <Info className="h-3.5 w-3.5" /> Good to know
            </p>
            <p className="mt-2 text-[11.5px] leading-relaxed text-ink/70">{tool.note}</p>
          </>
        ) : (
          <>
            <p className="text-[10.5px] font-semibold uppercase tracking-[0.1em] text-ink/75">Related tools</p>
            <div className="mt-2 space-y-1">
              {tool.related.slice(0, 3).map((id) => {
                const related = getTool(id);
                if (!related) return null;
                return (
                  <a key={id} href={`#/tool/${id}`} className="flex items-center gap-2 rounded-lg px-1 py-1 text-[12px] font-medium hover:bg-bone-deep/50">
                    <ToolTile tool={related} size="sm" />
                    {related.name}
                    <ArrowRight className="ml-auto h-3 w-3 text-ink/70" />
                  </a>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default function ToolPage({ toolId }: { toolId: string }) {
  const tool = getTool(toolId);
  if (!tool) return <NotFoundPage />;
  const Component = TOOL_COMPONENTS[tool.id];
  if (!Component) return <NotFoundPage />;
  const wide = WIDE_TOOLS.has(tool.id);
  return (
    <ToolShell tool={tool} wide={wide} aside={<WideAside tool={tool} />}>
      <Component />
    </ToolShell>
  );
}

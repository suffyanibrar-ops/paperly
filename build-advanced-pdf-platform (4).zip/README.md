# Paperly PDF

A commercial-grade, privacy-first PDF platform. **42 working tools** run inside the browser — documents are never uploaded to a server.

Production: <https://paperlypdf.netlify.app/>

## Architecture

| Layer | Technology |
| --- | --- |
| UI | React 19 + TypeScript, Tailwind CSS 4, Vite 7 |
| Routing | Hash routes for resilient static hosting + real path URLs for the prerendered Netlify deployment |
| PDF engine | PDF.js 6.2.108 (render, text), `@cantoo/pdf-lib` 2.11.1 (rewrite, AES-256, forms) |
| OCR | Tesseract.js 6 (WASM worker); engine + language data fetched from pinned CDNs on first use |
| Office | `docx`, patched SheetJS 0.20.3, `pptxgenjs`, JSZip |
| HTML → PDF | html2canvas over DOMPurify-sanitised markup |
| HTML sanitisation | DOMPurify 3.4.17 with a strict tag/attribute allowlist and CSS property allowlist |
| Build | `vite build` → single inlined `dist/index.html` → `scripts/prerender.mjs` writes 54 static SEO routes |

### Directory map

```
src/lib/security.ts      upload validation, magic bytes, zip-bomb guards, DOMPurify policy, safe errors
src/lib/pdf.ts           PDF.js/pdf-lib orchestration, canvas memory caps, managed document teardown
src/lib/toolRegistry.ts  single source of truth for all 42 tools (also parsed by the prerenderer)
src/tools/               tool implementations grouped by domain
src/pages/               marketing, legal, help, guides, comparison and activity pages
scripts/prerender.mjs    static SEO generation (titles, canonicals, OG, JSON-LD, sitemap, OG image)
scripts/serve-dist.cjs   production-parity QA server (applies netlify.toml CSP/security headers)
tests/unit               Vitest + Testing Library (security, uploads)
tests/e2e                Playwright output-verification suite
```

## Tool test matrix

`tests/e2e/matrix-a.spec.ts` (25 tests) and `matrix-b.spec.ts` (26 tests) exercise **all 42 registered tools** plus malformed-input, malicious-archive, wrong-password and 120-page large-file cases, asserting generated output (page counts, extracted text, form values, encryption, ZIP contents, image signatures) rather than button clicks. `tests/unit/zip.test.ts` adds 21 adversarial central-directory fixtures.

| Tool | Verified behaviour | Tool | Verified behaviour |
| --- | --- | --- | --- |
| merge | 5-page merge | split | exact page extraction |
| organize | delete + reorder | rotate | rotation maths |
| crop | crop box | compress | smaller + valid |
| repair | rebuilt PDF | page-numbers | stamped text |
| jpg-to-pdf | A4 output | pdf-to-jpg | 3 JPEGs in ZIP |
| pdf-to-word | DOCX text | pdf-to-excel | 3 sheets |
| pdf-to-ppt | 3 slides | word-to-pdf | headings/tables |
| excel-to-pdf | XLSX + CSV | ppt-to-pdf | slide text |
| extract-text | real text layer | ocr | searchable text |
| scan | photo → PDF | html-to-pdf | source attachment |
| markdown-to-pdf | typeset text | pdf-to-markdown | YAML + content |
| resize | A4 geometry | n-up | 2 imposed sheets |
| headers-footers | placeholders | bates | sequential numbers |
| fill-forms | persisted values | flatten | zero fields |
| archive | metadata + attachment | batch | 2-file ZIP |
| create-form | 3 real fields | remove-pages | correct page gone |
| extract-pages | range order | extract-images | original bytes |
| summarize | verbatim passages | edit | text + pages kept |
| sign | embedded signature | watermark | every page |
| protect | AES-256 required | unlock | decrypt + wrong password |
| redact | text truly removed | compare | differences detected |

## Commands

```bash
npm install
npm run dev              # local development
npm run build            # production build + SEO prerender
npm run preview          # preview the built app
npm run typecheck        # tsc --noEmit
npm run lint             # ESLint (flat config)
npm test                 # Vitest unit/integration tests
npm run test:coverage    # coverage with enforced thresholds
npm run test:e2e         # Playwright (production-parity server, gzip + real headers)
npm run test:e2e:install # install the Chromium binary once
```

## Security model

- **No document upload endpoint exists.** Files are read with the File API and processed in the tab.
- **Signature validation before parsing** for PDF/JPEG/PNG/GIF/WebP/AVIF/TIFF and OOXML; a text file renamed `.pdf` is rejected.
- **Zip guards** for DOCX/XLSX/PPTX: entry count, uncompressed size, compression ratio, traversal paths and encrypted entries.
- **Spreadsheet parsing** disables formula evaluation, HTML export and VBA; sheet/row counts are bounded.
- **HTML → PDF** strips scripts, frames, objects, forms, SVG, event handlers and remote resources via DOMPurify plus a second DOM pass; inline CSS is filtered by property allowlist; rendering happens off-screen in an inert subtree.
- **Resource limits**: PDF ≤ 200 MB / 1,000 pages, images ≤ 40 MB, canvas ≤ 40 MP; OOM errors are mapped to actionable messages.
- **Redaction** rasterises affected pages and burns the redactions into the image, so extracted text is genuinely removed. Unmarked pages keep selectable text.
- **Encryption** uses AES-256 and self-verifies that the output requires the password. Passwords never leave the tab.
- **Security headers** (CSP, HSTS, nosniff, frame-deny, referrer and permissions policy) are declared in `netlify.toml` and verified by the Playwright suite.

## Privacy disclosures

External requests are limited to: Google Fonts (interface typography), and — only when OCR is used — `cdn.jsdelivr.net` (pinned OCR worker/core) and `tessdata.projectnaptha.com` (language data). Document pages are never sent to those hosts. Local activity stores tool name, output filename, pages, size and timestamp under `paperly.activity.v1`; clear it from **Activity**.

## Known, disclosed limitations

1. **Single-file bundle.** `vite-plugin-singlefile` inlines the app; the PDF.js worker is now a separate same-origin asset (`/pdf.worker.min.mjs`) and the HTML is 3.37 MB (gzip 1.09 MB). Remaining route-level splitting requires a build-config change (not performed). CSP therefore still needs `'unsafe-inline'`.
2. **OCR needs a network fetch once** for the engine/language data. There is no bundled OCR model.
3. **PDF/A is not certified.** The Archive tool produces an archival copy and a readiness report; validate with veraPDF if you need formal conformance.
4. **Signatures are visual**, not certificate-backed.
5. **Office conversion is text-first**; complex layout fidelity is not guaranteed.
6. **Certified compliance, native apps, cloud-storage integrations and AI translation are not offered.** The comparison page says so explicitly.

## Deployment (Netlify)

1. Connect the repository; Netlify reads `netlify.toml` (`npm run build`, publish `dist`).
2. Set `PAPERLY_ORIGIN=https://paperlypdf.netlify.app` (or the custom domain) so canonical URLs and the sitemap use the correct host.
3. Deploy, then verify headers with `curl -I https://<domain>/` and confirm `/sitemap.xml`, `/robots.txt`, `/pdf.worker.min.mjs` and a prerendered route such as `/tool/merge`. The audit found the previous deployment serving none of these — a redeploy is required.
4. No private environment variables are read by client code; do not add secrets to Vite variables.

## Reporting security issues

Email `privacy@paperly.tools`. Do not attach sensitive documents.

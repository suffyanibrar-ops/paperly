# Security policy and verified controls

_Last verified: production-build audit, February 2026._

## Threat model

Paperly is a client-side application with no document-processing backend. The primary risks are therefore **malicious input files**, **untrusted markup** and **supply-chain compromise** — not server-side data breaches.

## Controls and evidence

| Control | Implementation | Verification |
| --- | --- | --- |
| No document upload | File API + in-tab engines | Merge e2e watches for non-GET requests; 0 observed |
| File type validation | magic bytes + size + accept list (`src/lib/security.ts`) | 8 unit tests + e2e rejection of a fake PDF |
| ZIP validation | **central-directory** inspection (EOCD/ZIP64, data-descriptor safe, duplicate/encrypted/traversal/ratio/size checks, local-header cross-check) | 21 adversarial unit tests in `tests/unit/zip.test.ts` |
| Office parser hardening | formula/VBA/HTML disabled, row & sheet caps | SheetJS upgrade regression + e2e fixtures |
| HTML sanitisation | DOMPurify allowlist + DOM second pass + CSS allowlist | 12 unit tests including scripts, iframes, SVG, `javascript:`, remote images, `position:fixed`, `url()` |
| Remote resource blocking | only `data:image/*` survives in HTML conversion | e2e asserts zero `evil.test` requests |
| Resource limits | 200 MB PDF / 1,000 pages / 40 MP canvas / 25–80 MB Office | unit tests + shipped constants |
| Memory safety | loading-task teardown shim, `page.cleanup()`, canvas release, OOM error mapping | PDF.js 6 upgrade verified by e2e merge; manual 80-page test |
| Redaction | page rasterisation + burned pixels | e2e + **independent Poppler**: redacted page 1 = 0 extractable chars, page 3 = 279 chars, sensitive token absent from page 1; `qpdf --check` clean |
| Encryption | AES-256 via Web Crypto, verified output | e2e + **independent qpdf/Poppler**: `R = 6`, `AES-256`, wrong password rejected, unlock output has zero `/Encrypt` |
| Security headers | `netlify.toml` CSP/HSTS/frame-deny/permissions | PASS locally via production-parity server (CSP + gzip verified). **Live domain still serves the previous build without CSP** — redeploy required. |
| Dependencies | SheetJS 0.20.3 from official CDN, PDF.js 6.2.108, image-size override 2.0.4, Vite 7.3.7 | `npm audit --omit=dev` → **0 vulnerabilities**; full audit 0 high/critical (11 moderate dev-only ESLint/minimatch) |

## Dependency provenance

- `xlsx@0.20.3` is installed from `https://cdn.sheetjs.com/xlsx-0.20.3/xlsx-0.20.3.tgz` (the vendor’s official distribution channel; the npm registry copy remains at 0.18.5 and is vulnerable to CVE-2023-30533 and CVE-2024-22363).
- `pdfjs-dist@6.2.108` fixes GHSA-hq66-cqwq-w95j (arbitrary JavaScript via a malicious PDF).
- `image-size@2.0.4` is enforced with an npm override to fix GHSA-5p2g-fcmc-qvqq / GHSA-w3rx-r6r6-pgpr pulled in by `pptxgenjs`; the PPTX writer was regression-tested after the override.

## Known limitations

1. CSP requires `'unsafe-inline'` because the production build inlines the application bundle and styles into one HTML file (`vite-plugin-singlefile`). External origins remain restricted.
2. HTML conversion executes no scripts, but it is not a formally sandboxed origin (separate-origin iframe or server-side rendering). Isolation relies on allowlist sanitisation, inert rendering and CSP.
3. OCR downloads third-party engine files at runtime; pinning versions reduces, but cannot eliminate, upstream risk.
4. Visual signatures are not certificate-backed and must not be represented as qualified e-signatures.

## Reporting

Email `privacy@paperly.tools` with reproduction steps. Never include sensitive documents; a minimal synthetic PDF is enough.

## Independent verification log (latest audit)

Commands run against artefacts produced by the Playwright matrix:

```text
$ qpdf --show-encryption --password='' protect-sample-protected.pdf
Incorrect password supplied
R = 6
P = -1340
print high resolution: allowed      extract for any purpose: not allowed

$ pdfinfo -upw 'Matrix-Passphrase1!' protect-sample-protected.pdf
Pages: 3   Encrypted: yes (... algorithm:AES-256)

$ qpdf --check --password='wrong' protect-sample-protected.pdf
qpdf: ...: invalid password

$ grep -ac '/Encrypt' unlock-encrypted-unlocked.pdf
0

$ pdftotext -f 1 -l 1 redact-sample-redacted.pdf - | tr -d '[:space:]' | wc -c
0
$ pdftotext -f 3 -l 3 redact-sample-redacted.pdf - | grep -c '99887766'
1        # untouched page retains its own text, as designed
$ qpdf --check redact-sample-redacted.pdf
No syntax or stream encoding errors found
```

## Remaining limitations (not resolved in this audit)

1. **CSP uses `'unsafe-inline'`** for the inlined single-file bundle/styles.
2. **Single-file bundle** keeps OCR-independent libraries (SheetJS, docx, pptxgenjs, html2canvas, JSZip) in the initial payload. The PDF.js worker was extracted to `/pdf.worker.min.mjs`, cutting the HTML from 4.6 MB to 3.37 MB (gzip 1.46 MB → 1.09 MB), but route-level splitting requires changing `vite.config.ts`.
3. **Throttled mobile FCP is 6.7 s** (slow 3G, 4× CPU, gzip enabled). CLS 0.088. LCP was not captured reliably in this harness.
4. **Live deployment is stale** (no CSP, no prerendered routes, no sitemap). Local production build is verified; redeploy is outstanding.
5. **Chromium-only** browser automation; Firefox/WebKit untested.
6. **No security certification** is claimed: controls are tested behaviours, not an audit certification.
